package edu.upc.dsa.models;

import edu.upc.dsa.util.RandomUtils;
import java.util.UUID;

public class Track {

    String id;
    String title;
    String singer;

    public Track() {
        this.setId(UUID.randomUUID().toString()); // Generar un UUID automáticamente si no se proporciona uno.
    }

    public Track(String title, String singer) {
        this(UUID.randomUUID().toString(), title, singer); // Generar UUID si no hay ID
    }

    public Track(String id, String title, String singer) {
        if (id == null || id.isEmpty()) {
            this.setId(UUID.randomUUID().toString()); // Generar UUID si el ID es null o vacío
        } else {
            this.setId(id);
        }
        this.setSinger(singer);
        this.setTitle(title);
    }

    // Getters y setters
    public String getId() {
        return this.id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSinger() {
        return singer;
    }

    public void setSinger(String singer) {
        this.singer = singer;
    }

    @Override
    public String toString() {
        return "Track [id=" + id + ", title=" + title + ", singer=" + singer + "]";
    }
}
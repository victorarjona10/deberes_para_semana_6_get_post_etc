package edu.upc.dsa.exceptions;

public class TrackNotFoundException extends Exception {
}

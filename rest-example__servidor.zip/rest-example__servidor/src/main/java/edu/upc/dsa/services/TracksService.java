package edu.upc.dsa.services;


import edu.upc.dsa.TracksManager;
import edu.upc.dsa.TracksManagerImpl;
import edu.upc.dsa.models.Track;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import javax.ws.rs.*;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.List;


import java.util.UUID;

@Api(value = "/tracks", description = "Endpoint to Track Service")
@Path("/tracks")
public class TracksService {

    private TracksManager tm;

    public TracksService() {
        this.tm = TracksManagerImpl.getInstance();
        if (tm.size() == 0) {
            this.tm.addTrack(UUID.randomUUID().toString(), "La Barbacoaaaa", "Georgie Dann");
            this.tm.addTrack(UUID.randomUUID().toString(), "Despacito", "Luis Fonsi");
            this.tm.addTrack(UUID.randomUUID().toString(), "Enter Sandman", "Metallica");
        }
    }

    @GET
    @ApiOperation(value = "get all Tracks", notes = "Retrieve all tracks")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successful", response = Track.class, responseContainer = "List"),
    })
    @Path("/")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getTracks() {
        List<Track> tracks = this.tm.findAll();
        GenericEntity<List<Track>> entity = new GenericEntity<List<Track>>(tracks) {};
        return Response.status(200).entity(entity).build();
    }

    @GET
    @ApiOperation(value = "get a Track by ID", notes = "Retrieve a track by its ID")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successful", response = Track.class),
            @ApiResponse(code = 404, message = "Track not found")
    })
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getTrack(@PathParam("id") String id) {
        Track t = this.tm.getTrack(id);
        if (t == null) {
            return Response.status(404).build();
        }
        return Response.status(200).entity(t).build();
    }

    @DELETE
    @ApiOperation(value = "delete a Track", notes = "Delete a track by its ID")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successful"),
            @ApiResponse(code = 404, message = "Track not found")
    })
    @Path("/{id}")
    public Response deleteTrack(@PathParam("id") String id) {
        Track t = this.tm.getTrack(id);
        if (t == null) {
            return Response.status(404).build();
        }
        this.tm.deleteTrack(id);
        return Response.status(200).build();
    }

    @PUT
    @ApiOperation(value = "update a Track", notes = "Update a track's information")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successful"),
            @ApiResponse(code = 404, message = "Track not found")
    })
    @Path("/")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response updateTrack(Track track) {
        Track t = this.tm.updateTrack(track);
        if (t == null) {
            return Response.status(404).build();
        }
        return Response.status(200).build();
    }

    @POST
    @ApiOperation(value = "create a new Track", notes = "Add a new track")
    @ApiResponses(value = {
            @ApiResponse(code = 201, message = "Successful", response = Track.class),
            @ApiResponse(code = 400, message = "Validation Error")
    })
    @Path("/")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response newTrack(Track track) {
        // Generate a UUID if the track ID is null or empty
        if (track.getId() == null || track.getId().isEmpty()) {
            track.setId(UUID.randomUUID().toString());
        }

        // Validate that the track has both a title and singer
        if (track.getSinger() == null || track.getTitle() == null) {
            return Response.status(400).entity("Title and singer are required").build();
        }
        else
        {
            this.tm.addTrack(track);
            return Response.status(201).entity(track).build();
        }

    }
}


//@Api(value = "/tracks", description = "Endpoint to Track Service")
//@Path("/tracks")
//public class TracksService {
//
//    private TracksManager tm;
//
//    public TracksService() {
//        this.tm = TracksManagerImpl.getInstance();
//        if (tm.size()==0) {
//            this.tm.addTrack("La Barbacoa", "Georgie Dann");
//            this.tm.addTrack("Despacito", "Luis Fonsi");
//            this.tm.addTrack("Enter Sandman", "Metallica");
//        }
//
//
//    }
//
//    @GET
//    @ApiOperation(value = "get all Track", notes = "asdasd")
//    @ApiResponses(value = {
//            @ApiResponse(code = 201, message = "Successful", response = Track.class, responseContainer="List"),
//    })
//    @Path("/")
//    @Produces(MediaType.APPLICATION_JSON)
//    public Response getTracks() {
//
//        List<Track> tracks = this.tm.findAll();
//
//        GenericEntity<List<Track>> entity = new GenericEntity<List<Track>>(tracks) {};
//        return Response.status(201).entity(entity).build()  ;
//
//    }
//
//    @GET
//    @ApiOperation(value = "get a Track", notes = "asdasd")
//    @ApiResponses(value = {
//            @ApiResponse(code = 201, message = "Successful", response = Track.class),
//            @ApiResponse(code = 404, message = "Track not found")
//    })
//    @Path("/{id}")
//    @Produces(MediaType.APPLICATION_JSON)
//    public Response getTrack(@PathParam("id") String id) {
//        Track t = this.tm.getTrack(id);
//        if (t == null) return Response.status(404).build();
//        else  return Response.status(201).entity(t).build();
//    }
//
//    @DELETE
//    @ApiOperation(value = "delete a Track", notes = "asdasd")
//    @ApiResponses(value = {
//            @ApiResponse(code = 201, message = "Successful"),
//            @ApiResponse(code = 404, message = "Track not found")
//    })
//    @Path("/{id}")
//    public Response deleteTrack(@PathParam("id") String id) {
//        Track t = this.tm.getTrack(id);
//        if (t == null) return Response.status(404).build();
//        else this.tm.deleteTrack(id);
//        return Response.status(201).build();
//    }
//
//    @PUT
//    @ApiOperation(value = "update a Track", notes = "asdasd")
//    @ApiResponses(value = {
//            @ApiResponse(code = 201, message = "Successful"),
//            @ApiResponse(code = 404, message = "Track not found")
//    })
//    @Path("/")
//    public Response updateTrack(Track track) {
//
//        Track t = this.tm.updateTrack(track);
//
//        if (t == null) return Response.status(404).build();
//
//        return Response.status(201).build();
//    }
//
//
//
//    @POST
//    @ApiOperation(value = "create a new Track", notes = "asdasd")
//    @ApiResponses(value = {
//            @ApiResponse(code = 201, message = "Successful", response=Track.class),
//            @ApiResponse(code = 500, message = "Validation Error")
//
//    })
//
//    @Path("/")
//    @Consumes(MediaType.APPLICATION_JSON)
//    public Response newTrack(Track track) {
//
//        if (track.getSinger()==null || track.getTitle()==null)  return Response.status(500).entity(track).build();
//        this.tm.addTrack(track);
//        return Response.status(201).entity(track).build();
//    }
//
//}